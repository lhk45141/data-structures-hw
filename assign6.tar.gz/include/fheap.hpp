#ifndef __FHEAP_H_
#define __FHEAP_H_

#include <iostream>
#include <initializer_list>
#include <optional>
#include <vector>
#include <cmath>
#include <memory>
#include <queue>

template <typename T>
class PriorityQueue {
    public:
        virtual void insert(const T& item) = 0;
        virtual std::optional<T> extract_min() = 0;
        virtual bool is_empty() const = 0;
};

template <typename T>
class FibonacciNode {
    public:
        // constructors
        FibonacciNode()
            :key(std::nullopt), degree(0), child(nullptr), right(nullptr) {}
        FibonacciNode(const T& item)
            :key(item), degree(0), child(nullptr), right(nullptr) {}

        // destructor
        ~FibonacciNode() = default;

        T key;
        size_t degree;

        std::shared_ptr<FibonacciNode<T>> right;
        std::shared_ptr<FibonacciNode<T>> child;
        // NOTE: If you set left/parent pointer to shared_ptr, circular reference may cause!
        // So, left/parent pointer should be set to weak_ptr.
        std::weak_ptr<FibonacciNode<T>> left;
        std::weak_ptr<FibonacciNode<T>> parent;
};

template <typename T>
class FibonacciHeap : public PriorityQueue<T> {
    public:
        // Default Constructor
        FibonacciHeap()
            : min_node(nullptr), size_(0) {}

        // Constructor with Value
        FibonacciHeap(const T& item)
            : min_node(nullptr), size_(0) { insert(item); }

        // Disable copy constructor.
        FibonacciHeap(const FibonacciHeap<T> &);

        // Constructor with initializer_list
        // ex) FibonacciHeap<int> fheap = {1, 2, 3, 4};
        FibonacciHeap(std::initializer_list<T> list): min_node(nullptr), size_(0) {
            for(const T& item : list) {
                insert(item);
            }
        }

        // Destructor
        ~FibonacciHeap();

        // Insert item into the heap.
        void insert(const T& item) override;

        // Return raw pointer of the min node.
        // If the heap is empty, return nullptr.
        FibonacciNode<T>* get_min_node() { return min_node.get(); }

        // Return minimum value of the min node.
        // If the heap is empty, return std::nullopt.
        std::optional<T> get_min() const;

        // 1. Return minimum value of the min node
        // 2. Remove the node which contains minimum value from the heap.
        // If the heap is empty, return std::nullopt;
        std::optional<T> extract_min() override;

        // Return true if the heap is empty, false if not.
        bool is_empty() const override { return !size_; }

        // Return the number of nodes the heap contains.
        size_t size() const { return size_; }


    private:
        // Points to the node which has minimum value.
        std::shared_ptr<FibonacciNode<T>> min_node;

        // Value that represents how many nodes the heap contains.
        size_t size_;

        void insert(std::shared_ptr<FibonacciNode<T>>& node);

        // After extract, clean up the heap.
        void consolidate();

        // Combine two nodes.
        void merge(std::shared_ptr<FibonacciNode<T>>& x, std::shared_ptr<FibonacciNode<T>>& y);
};

template <typename T>
FibonacciHeap<T>::~FibonacciHeap() {
    min_node.reset();
	// TODO
}

template <typename T>
std::optional<T> FibonacciHeap<T>::get_min() const {
	if (min_node==nullptr)
		return std::nullopt;
   	return min_node->key;
	// TODO
    return std::nullopt;
}

template <typename T>
void FibonacciHeap<T>::insert(const T& item) {
	if (min_node==nullptr){
		min_node.reset(new FibonacciNode(item));
		min_node->right=min_node;
		min_node->left=(min_node);
	}
	else{
	std::shared_ptr<FibonacciNode<T>> ins_item(new FibonacciNode(item));
	ins_item->left=min_node->left;
	min_node->left.lock()->right=ins_item;//left->nono
	min_node->left=ins_item;
       	ins_item->right=min_node;
     	if (min_node->key>ins_item->key)
    		min_node=ins_item;
	}
	size_++;
    // TODO
}

template <typename T>
void FibonacciHeap<T>::insert(std::shared_ptr<FibonacciNode<T>>& node) {
   	 node->left=min_node->left;
	 {min_node->left.lock()->right=node;//left->nono
	 }min_node->left=node;
	 node->right=min_node;

	 if(min_node->key>node->key)
	    min_node=node;
	 size_++;
	// TODO
}

template <typename T>
std::optional<T> FibonacciHeap<T>::extract_min() {
	if (min_node==nullptr)
		return std::nullopt;
	std::optional<T> min=min_node->key;
	if (size_==1){
		min_node.reset();
		size_=0;
		return min;
	}

	if (min_node->degree!=0){
	min_node->child->left.lock()->right=min_node->right;
	min_node->right->left=min_node->child->left;

	min_node->left.lock()->right=min_node->child;
	min_node->child->left=min_node->left;

	min_node=min_node->child;
	}
	else{
	min_node->left.lock()->right=min_node->right;
	min_node->right->left=min_node->left;
	min_node=min_node->right;
	}
	size_--;
   	consolidate();
    
    	return min;
	// TODO
    return std::nullopt;
}

template <typename T>
void FibonacciHeap<T>::consolidate() {
	std::vector<std::shared_ptr<FibonacciNode<T>>> root(size_);	
	T cur_key=min_node->key;
	std::shared_ptr<FibonacciNode<T>> node_name=min_node;//->right;
	do{	
	if (!root[node_name->degree]){
		root[node_name->degree]=node_name;
		node_name=node_name->right;
	}
	else if (root[node_name->degree]){
		if (root[node_name->degree]->key<=node_name->key){//root[~]는 피보나치 노드, node_name은 shared ptr? 접근 다르게?
			
			merge(root[node_name->degree],node_name);
		}
		else if(root[node_name->degree]->key>node_name->key){
			min_node=node_name;
			merge(node_name,root[node_name->degree]);
			}
		 root.clear();//[]붙이는게 맞나?
		return consolidate();
			}
		
	}while(node_name!=min_node);

	for (int i=0; i<size_;i++){
		if (root[i]!=nullptr){
		if (root[i]->key<min_node->key)
			min_node=root[i];
		}
	}
	 root.clear();	//[]붙이는게 맞나?
    // TODO
}

template <typename T>
void FibonacciHeap<T>::merge(std::shared_ptr<FibonacciNode<T>>& x, std::shared_ptr<FibonacciNode<T>>& y) {
	y->right->left=y->left;
	y->left.lock()->right=y->right;
	
	if(x->degree==0){
		x->child=y;
		y->parent=x;
		y->left=y;
		y->right=y;
		x->degree=1;
	}
	else{
	y->right=x->child;
	y->left=x->child->left;
	x->child->left.lock()->right=y;
	x->child->left=y;
	y->parent=x;
	
	x->degree++;
	}
    // TODO
}

#endif // __FHEAP_H_
