#include <algorithm>
#include <iostream>
#include <vector>
#include <functional>
#include <iterator>
#include <memory>

#define INITIAL_TABLE_SIZE 64

#include "hash_slot.hpp"

/* Fill in the TODO sections in the following code. */

template <typename K, typename V, typename F>
class HashTable {
public:
    HashTable();
    ~HashTable();
    int get(const K &key, V &value);
    int put(const K &key, const V &value);
    int remove(const K &key);
    size_t get_table_size();
    size_t get_size();
    double get_load_factor();

protected:
    size_t table_size;
    
private:
    HashTable(const HashTable & other);
    const HashTable & operator=(const HashTable & other);
    F hash_func;
    size_t size;
    HashSlot<K, V> *table;

    // Should be overriden by the derived class
    virtual unsigned long get_next_pos(unsigned long pos,
                                       unsigned long step) = 0;
    unsigned long get_pos(const K key);
    void enlarge_table();
};

template <typename K, typename V, typename F>
class LinearProbeHashTable: public HashTable<K, V, F> {
private:
    virtual unsigned long get_next_pos(unsigned long pos, unsigned long step) {
	return ++pos % this->table_size;
	// TODO
        return 0;
    }
};

template <typename K, typename V, typename F>
class QuadProbeHashTable: public HashTable<K, V, F> {
private:
    virtual unsigned long get_next_pos(unsigned long pos, unsigned long step) {
        return (pos + step) % this->table_size;
	// TODO
        return 0;
    }
};

template <typename K, typename V, typename F>
HashTable<K, V, F>::HashTable(): table(), hash_func(),
                                 size(0), table_size(INITIAL_TABLE_SIZE) {
    table = new HashSlot<K, V>[table_size];
}

template <typename K, typename V, typename F>
HashTable<K, V, F>::~HashTable() {
    delete[] table;
    // TODO
}

template <typename K, typename V, typename F>
void HashTable<K, V, F>::enlarge_table() {
    HashSlot<K, V>* temp = table;
    table = new HashSlot<K, V>[table_size * 2];
    table_size *= 2;
    size = 0;
    for (auto i = 0; i < table_size / 2; i++)
	if (!temp[i].is_empty() && !temp[i].is_removed()) put(temp[i].get_key(), temp[i].get_value());
    delete[] temp;
	
    // TODO
}

template <typename K, typename V, typename F>
unsigned long HashTable<K, V, F>::get_pos(const K key) {
    return hash_func(key) % table_size;
    // TODO
    return 0;
}

template <typename K, typename V, typename F>
int HashTable<K, V, F>::get(const K &key, V &value) {
    auto pos = get_pos(key);

    for (auto i = 1; i <= table_size; i++) {
	if (!table[pos].is_empty() && !table[pos].is_removed() && table[pos].get_key() == key) {
	    value = table[pos].get_value();
	    return --i;
	}
	if (table[pos].is_empty()) return -1;
	pos = get_next_pos(pos, i);
    }
	
    // TODO
    return -1;
}

template <typename K, typename V, typename F>
int HashTable<K, V, F>::put(const K &key, const V &value) {
    auto pos = get_pos(key);

    for (auto i = 1; i <= table_size; i++) {
        if (table[pos].is_empty() || table[pos].is_removed()) {
            size++;
	    table[pos].set_key_value(key, value);
	    if (get_load_factor() >= 0.5) enlarge_table();
            return --i;
        }
        if (!table[pos].is_removed() && table[pos].get_key() == key) return -1;
	pos = get_next_pos(pos, i);
    }       
        
    // TODO
    return -1;
}

template <typename K, typename V, typename F>
int HashTable<K, V, F>::remove(const K &key) {
    auto step = 0, pos = get_pos(key);

    for (auto i = 1; i <= table_size; i++) {
        if (!table[pos].is_empty() && !table[pos].is_removed() && table[pos].get_key() == key) {
            size--;
	    table[pos].set_removed();
            return --i;
        }
        if (table[pos].is_empty()) return -1;
	pos = get_next_pos(pos, i);
    }       
        
    // TODO
    return -1;
}

template <typename K, typename V, typename F>
size_t HashTable<K, V, F>::get_table_size() {
    return table_size;
}

template <typename K, typename V, typename F>
size_t HashTable<K, V, F>::get_size() {
    return size;
}

template <typename K, typename V, typename F>
double HashTable<K, V, F>::get_load_factor() {
    return (double)size/table_size;
}
